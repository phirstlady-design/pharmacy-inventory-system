<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$id = $_GET['id'];

$sale = $pdo->prepare("SELECT * FROM sales WHERE id=?");
$sale->execute([$id]);
$sale = $sale->fetch();

$items = $pdo->prepare("
    SELECT si.*, p.product_name
    FROM sale_items si
    JOIN products p ON p.id = si.product_id
    WHERE si.sale_id=?
");
$items->execute([$id]);
$items = $items->fetchAll();
?>
<?php require_once '../../includes/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Receipt</title>

    <style>
        body {
            font-family: monospace;
            width: 280px; /* 80mm thermal printer */
            margin: 0 auto;
            font-size: 12px;
        }

        .center {
            text-align: center;
        }

        .line {
            border-top: 1px dashed #000;
            margin: 5px 0;
        }

        table {
            width: 100%;
            font-size: 12px;
        }

        td {
            padding: 2px 0;
        }

        .right {
            text-align: right;
        }

        .btn-print {
            margin-top: 10px;
            width: 100%;
            padding: 10px;
        }

        @media print {
            .btn-print {
                display: none;
            }
        }
    </style>
</head>

<body>

<div class="center">
    <h3>MY PHARMACY</h3>
    <p>Osun State, Nigeria</p>
    <p>Tel: 08065182627</p>
</div>

<div class="line"></div>

<p>Invoice: <?= $sale['invoice_no'] ?></p>
<p>Date: <?= $sale['created_at'] ?></p>

<div class="line"></div>

<table>
    <tr>
        <td><b>Item</b></td>
        <td class="right"><b>Total</b></td>
    </tr>

    <?php foreach($items as $i): ?>
        <tr>
            <td>
                <?= $i['product_name'] ?><br>
                <?= $i['quantity'] ?> x <?= $i['unit_price'] ?>
            </td>
            <td class="right">
                <?= number_format($i['subtotal'],2) ?>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<div class="line"></div>

<h3 class="right">
    TOTAL: ₦<?= number_format($sale['total_amount'],2) ?>
</h3>

<div class="line"></div>

<p class="center">Thank you for your purchase</p>

<button class="btn-print" onclick="window.print()">PRINT</button>



<script>
window.onload = function () {
    window.print();
};
</script>

</body>
</html>