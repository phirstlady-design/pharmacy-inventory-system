<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$products = $pdo->query("SELECT * FROM products")->fetchAll(PDO::FETCH_ASSOC);
$cart = $_SESSION['cart'] ?? [];



if(isset($_GET['barcode'])) {

    $barcode = $_GET['barcode'];

    $stmt = $pdo->prepare("SELECT * FROM products WHERE barcode=?");
    $stmt->execute([$barcode]);
    $product = $stmt->fetch();

    if($product) {

        $_SESSION['cart'][$product['id']] =
            ($_SESSION['cart'][$product['id']] ?? 0) + 1;
    }

    header("Location: pos.php");
    exit();
}
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>PRO POS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">

<!-- <div class="container-fluid mt-2"style="padding-left: 300px; padding-top: 50px;"> -->
    <div class="container-fluid mt-2" style="padding-left: 300px; padding-top: 50px;">

    <div class="row">

        <!-- LEFT: PRODUCTS -->
        <div class="col-md-8">

            <div class="card shadow">
                <div class="card-header bg-primary text-white">
                    <h4>Product List</h4>
                </div>
                    <form method="GET" class="mb-3">
                                    <div class="card-body">
                                        <input type="text" id="barcode" class="form-control mb-3"
                                        placeholder="Scan or enter barcode...">
                                        
                         <input type="text" id="search"  name="search" class="form-control"
                            placeholder="Search product or barcode...">
                            
                    </form>

                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Qty</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody id="productTable">

                        <?php foreach($products as $p): ?>
                            <tr>
                                <form method="POST" action="cart.php">
                                    <td><?= $p['product_name'] ?></td>
                                    <td><?= $p['selling_price'] ?></td>
                                    <td><?= $p['quantity'] ?></td>

                                    <td style="width:80px;">
                                        <input type="number" name="quantity"
                                               value="1" class="form-control">
                                    </td>

                                    <td>
                                        <input type="hidden" name="product_id" value="<?= $p['id'] ?>">
                                        <button name="add" class="btn btn-success btn-sm">
                                            Add
                                        </button>
                                    </td>
                                </form>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>
            </div>

        </div>

        <!-- RIGHT: CART -->
        <div class="col-md-4">

            <div class="card shadow">
                <div class="card-header bg-dark text-white">
                    <h4>Cart</h4>
                </div>

                <div class="card-body" >

                    <?php $total = 0; ?>

                    <table class="table table-sm">
                        <tr>
                            <th>Item</th>
                            <th>Qty</th>
                            <th></th>
                        </tr>

                        <?php foreach($cart as $id => $qty):

                            $stmt = $pdo->prepare("SELECT * FROM products WHERE id=?");
                            $stmt->execute([$id]);
                            $p = $stmt->fetch();

                            if(!$p) continue;

                            $total += $p['selling_price'] * $qty;
                        ?>

                        <tr>
                            <td><?= $p['product_name'] ?></td>
                            <td><?= $qty ?></td>
                            <td>
                                <a href="cart.php?remove=<?= $id ?>" class="btn btn-danger btn-sm">X</a>
                            </td>
                        </tr>

                        <?php endforeach; ?>

                    </table>

                    <hr>

                    <h4>Total: ₦<?= number_format($total,2) ?></h4>

                    <a href="checkout.php" class="btn btn-primary w-100 mt-2">
                        Checkout
                    </a>

                    <a href="cart.php?clear=1" class="btn btn-warning w-100 mt-2">
                        Clear Cart
                    </a>

                </div>
            </div>

        </div>

    </div>

</div>


<script>
document.getElementById("barcode").addEventListener("keypress", function(e) {
    if(e.key === "Enter") {
        let code = this.value;

        window.location.href = "pos.php?barcode=" + code;
    }
});
</script>


<script>
document.getElementById("search").addEventListener("keyup", function () {

    let value = this.value.toLowerCase();
    let rows = document.querySelectorAll("#productTable tr");

    rows.forEach(row => {
        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(value) ? "" : "none";
    });

});
</script>
<script>

   
let barcodeTimer;

const barcodeInput = document.getElementById('barcode');

barcodeInput.addEventListener('keyup', function(e) {

    clearTimeout(barcodeTimer);

    barcodeTimer = setTimeout(() => {

        let code = this.value.trim();

        if(code.length > 0) {

            fetch('api.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'action=barcode_add&barcode=' + encodeURIComponent(code)
            })
            .then(res => res.json())
            .then(data => {

                if(data.status === 'success') {
                    loadCart();
                    barcodeInput.value = '';
                    barcodeInput.focus();
                } else {
                    alert(data.msg);
                }
            });
        }

    }, 100);
});
</script> 
</body>
</html>