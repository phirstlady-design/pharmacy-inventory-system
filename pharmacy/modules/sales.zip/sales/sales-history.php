<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$sales = $pdo->query("SELECT * FROM sales ORDER BY created_at DESC")->fetchAll();
?>

<h2>Sales History</h2>

<table border="1" width="100%">
    <tr>
        <th>Invoice</th>
        <th>Total</th>
        <th>Date</th>
    </tr>

    <?php foreach($sales as $s): ?>
    <tr>
        <td><?= $s['invoice_no'] ?></td>
        <td><?= $s['total_amount'] ?></td>
        <td><?= $s['created_at'] ?></td>
    </tr>
    <?php endforeach; ?>
</table>