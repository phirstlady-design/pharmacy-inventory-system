<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

session_start();

$cart = $_SESSION['cart'] ?? [];

if(empty($cart)) {
    die("Cart is empty");
}

$pdo->beginTransaction();

$total = 0;

// calculate total first
foreach($cart as $id => $qty) {

    $p = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $p->execute([$id]);
    $product = $p->fetch();

    $total += $product['selling_price'] * $qty;
}

// create sale
$invoice = "INV-" . time();

$stmt = $pdo->prepare("INSERT INTO sales (invoice_no,total_amount,payment_method) VALUES (?,?,?)");
$stmt->execute([$invoice,$total,'cash']);

$sale_id = $pdo->lastInsertId();

// insert items + reduce stock
foreach($cart as $id => $qty) {

    $p = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $p->execute([$id]);
    $product = $p->fetch();

    $subtotal = $product['selling_price'] * $qty;

    $pdo->prepare("INSERT INTO sale_items (sale_id,product_id,quantity,unit_price,subtotal)
    VALUES (?,?,?,?,?)")->execute([
        $sale_id,$id,$qty,$product['selling_price'],$subtotal
    ]);

    // reduce stock
    $pdo->prepare("UPDATE products SET quantity = quantity - ? WHERE id=?")
        ->execute([$qty,$id]);
}

$pdo->commit();

unset($_SESSION['cart']);

header("Location: receipt.php?id=".$sale_id);
exit();
?>