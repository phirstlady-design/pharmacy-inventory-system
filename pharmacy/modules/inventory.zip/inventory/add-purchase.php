<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$success = '';
$error = '';

$suppliers = $pdo->query("SELECT * FROM suppliers ORDER BY supplier_name ASC")
                 ->fetchAll(PDO::FETCH_ASSOC);

$products = $pdo->query("SELECT * FROM products ORDER BY product_name ASC")
                ->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['save'])) {

    $supplier_id = $_POST['supplier_id'];
    $invoice_number = trim($_POST['invoice_number']);
    $payment_status = $_POST['payment_status'];

    $product_ids = $_POST['product_id'];
    $quantities = $_POST['quantity'];
    $prices = $_POST['unit_price'];

    $total_amount = 0;

  foreach($quantities as $index => $qty) {

    $qty = (int)$qty;
    $price = (float)$prices[$index];

    if($qty > 0 && $price > 0) {

        $subtotal = $qty * $price;
        $total_amount += $subtotal;
    }
}

    try {

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("INSERT INTO purchase_orders(
            supplier_id,
            invoice_number,
            total_amount,
            payment_status,
            created_by
        ) VALUES(?,?,?,?,?)");

        $stmt->execute([
            $supplier_id,
            $invoice_number,
            $total_amount,
            $payment_status,
            1
        ]);

        $purchase_id = $pdo->lastInsertId();

        foreach($product_ids as $index => $product_id) {

            $qty = (int)$quantities[$index];
                $price = (float)$prices[$index];

                if($qty <= 0 || $price <= 0) {
                    continue;
                }

                $subtotal = $qty * $price;

            $item = $pdo->prepare("INSERT INTO purchase_items(
                purchase_id,
                product_id,
                quantity,
                unit_price,
                subtotal
            ) VALUES(?,?,?,?,?)");

            $item->execute([
                $purchase_id,
                $product_id,
                $qty,
                $price,
                $subtotal
            ]);

            $updateStock = $pdo->prepare("UPDATE products
                SET quantity = quantity + ?
                WHERE id = ?");

            $updateStock->execute([$qty, $product_id]);
        }

        $pdo->commit();

        $success = 'Purchase added successfully';

    } catch(Exception $e) {

        $pdo->rollBack();
        $error = $e->getMessage();
    }
}
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="container-fluid mt-4" style="padding-left: 300px;">
    <!-- <div class="container mt-5" > -->

    <div class="card">

        <div class="card-header">
            <h4>Add Purchase</h4>
        </div>

        <div class="card-body">

            <?php if($success): ?>
                <div class="alert alert-success">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if($error): ?>
                <div class="alert alert-danger">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <form method="POST">

                <div class="row mb-3">

                    <div class="col-md-6">
                        <label>Supplier</label>

                        <select name="supplier_id" class="form-select" required>
                            <option value="">Select Supplier</option>

                            <?php foreach($suppliers as $supplier): ?>
                                <option value="<?= $supplier['id'] ?>">
                                    <?= htmlspecialchars($supplier['supplier_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label>Invoice Number</label>

                        <input type="text" name="invoice_number" class="form-control" required>
                    </div>

                </div>

                <div class="row mb-4">

                    <div class="col-md-6">
                        <label>Payment Status</label>

                        <select name="payment_status" class="form-select">
                            <option value="Paid">Paid</option>
                            <option value="Pending">Pending</option>
                        </select>
                    </div>

                </div>

                <table class="table table-bordered">

                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Unit Price</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php for($i = 0; $i < 5; $i++): ?>

                            <tr>

                                <td>
                                    <select name="product_id[]" class="form-select">
                                        <option value="">Select Product</option>

                                        <?php foreach($products as $product): ?>
                                            <option value="<?= $product['id'] ?>">
                                                <?= htmlspecialchars($product['product_name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>

                                <td>
                                    <input type="number" name="quantity[]" class="form-control">
                                </td>

                                <td>
                                    <input type="number" step="0.01" name="unit_price[]" class="form-control">
                                </td>

                            </tr>

                        <?php endfor; ?>

                    </tbody>

                </table>

                <button type="submit" name="save" class="btn btn-primary">
                    Save Purchase
                </button>

            </form>

        </div>

    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>