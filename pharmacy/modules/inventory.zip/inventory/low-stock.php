<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$stmt = $pdo->query("SELECT * FROM products WHERE quantity <= reorder_level");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Low Stock Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>



    </style>
</head>
<body>

<div class="container mt-5" style="padding-left: 300px;">

    <h3 class="mb-4">Low Stock Alert</h3>

    <div class="card shadow">
        <!-- <div class="card-body" style = "padding-right: 200px;"> -->
            <div class="card-body">

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Reorder Level</th>
                    </tr>
                </thead>

                <tbody>

                <?php foreach($products as $product): ?>

                    <tr>
                        <td><?= $product['product_name'] ?></td>
                        <td><?= $product['quantity'] ?></td>
                        <td><?= $product['reorder_level'] ?></td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>

        </div>
    </div>

</div>
<?php require_once '../../includes/footer.php'; ?>

</body>
</html>