<?php
include("include/connect.php"); // $conn = new mysqli(...);

// Get search, category, sort params safely
$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$sort = $_GET['sort'] ?? 'name';

// Validate sort column (allow only specific columns)
$allowedSorts = ['name', 'generic_name', 'manufacturer', 'category', 'price'];
if (!in_array($sort, $allowedSorts)) {
    $sort = 'name';
}

// Build SQL query with dynamic filters
$sql = "SELECT * FROM medicines WHERE 1=1";
$params = [];
$types = "";

if ($search !== '') {
    $sql .= " AND (name LIKE ? OR generic_name LIKE ? OR manufacturer LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $types .= "sss";
}

if ($category !== '') {
    $sql .= " AND category = ?";
    $params[] = $category;
    $types .= "s";
}

$sql .= " ORDER BY $sort";

// Prepare statement
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

if (!empty($params)) {
    // bind_param needs references, so use this workaround:
    $bind_names[] = $types;
    for ($i = 0; $i < count($params); $i++) {
        $bind_names[] = &$params[$i];
    }
    call_user_func_array([$stmt, 'bind_param'], $bind_names);
}

$stmt->execute();
$result = $stmt->get_result();

$medicines = [];
while ($row = $result->fetch_assoc()) {
    $medicines[] = $row;
}
$stmt->close();

// Get distinct categories
$categories = [];
$category_result = $conn->query("SELECT DISTINCT category FROM medicines ORDER BY category");
if ($category_result) {
    while ($row = $category_result->fetch_assoc()) {
        $categories[] = $row['category'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Medicine Inventory</title>
    <link rel="stylesheet" href="styles.css" />
    <link rel="stylesheet" href="vendor/bootstrap-5.2.3-dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome-free-5.15.4-web/css/all.css">
</head>
<body>
    <h1>Medicine Inventory</h1>

    <form method="get" action="">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search medicines..." />
        
        <select name="category">
            <option value="">All Categories</option>
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo htmlspecialchars($cat); ?>" <?php if ($cat === $category) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($cat); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="sort">
            <?php
            foreach ($allowedSorts as $col) {
                $selected = ($sort === $col) ? 'selected' : '';
                echo "<option value=\"$col\" $selected>" . ucfirst(str_replace('_', ' ', $col)) . "</option>";
            }
            ?>
        </select>

        <button type="submit">Filter</button>
    </form>

    <table border="1" cellpadding="8" cellspacing="0">
        <thead>
            <tr>
                <th>Name</th>
                <th>Generic Name</th>
                <th>Manufacturer</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Price</th>
                <!-- Add more columns as needed -->
            </tr>
        </thead>
        <tbody>
            <?php if (empty($medicines)): ?>
                <tr><td colspan="6">No medicines found.</td></tr>
            <?php else: ?>
                <?php foreach ($medicines as $med): ?>
                <tr>
                    <td><?php echo htmlspecialchars($med['name']); ?></td>
                    <td><?php echo htmlspecialchars($med['generic_name']); ?></td>
                    <td><?php echo htmlspecialchars($med['manufacturer']); ?></td>
                    <td><?php echo htmlspecialchars($med['category']); ?></td>
                    <td><?php echo (int)$med['quantity']; ?></td>
                    <td>#<?php echo number_format((float)$med['price'], 2); ?></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
     <script src="script.js"></script>
</body>
</html>
