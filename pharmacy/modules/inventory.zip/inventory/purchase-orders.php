<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$stmt = $pdo->query("
    SELECT
        purchase_orders.*,
        suppliers.supplier_name
    FROM purchase_orders
    LEFT JOIN suppliers
        ON purchase_orders.supplier_id = suppliers.id
    ORDER BY purchase_orders.id DESC
");

$purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<!-- <div class="container-fluid mt-4"> -->
    <div class="container-fluid mt-4" style="padding-left: 300px;">


    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Purchase Orders</h3>

        <a href="add-purchase.php" class="btn btn-primary">
            Add Purchase
        </a>
    </div>

    <div class="card">
        <div class="card-body">

            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Invoice</th>
                        <th>Supplier</th>
                        <th>Total Amount</th>
                        <th>Payment Status</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($purchases as $purchase): ?>

                        <tr>
                            <td><?= $purchase['id'] ?></td>
                            <td><?= htmlspecialchars($purchase['invoice_number']) ?></td>
                            <td><?= htmlspecialchars($purchase['supplier_name']) ?></td>
                            <td>₦<?= number_format($purchase['total_amount'], 2) ?></td>
                            <td><?= htmlspecialchars($purchase['payment_status']) ?></td>
                            <td><?= date('d M Y', strtotime($purchase['created_at'])) ?></td>

                            <td>
                                <a href="purchase-details.php?id=<?= $purchase['id'] ?>" class="btn btn-sm btn-info">
                                    View
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; ?>
                </tbody>
            </table>

        </div>
    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>