<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$id = $_GET['id'];

$stmt = $pdo->prepare("SELECT
    purchase_items.*,
    products.product_name
FROM purchase_items
LEFT JOIN products
    ON purchase_items.product_id = products.id
WHERE purchase_id = ?");

$stmt->execute([$id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="container-fluid mt-4" style="padding-left: 300px;">
>

    <div class="card">

        <div class="card-header">
            <h4>Purchase Details</h4>
        </div>

        <div class="card-body">

            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach($items as $item): ?>

                        <tr>
                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>₦<?= number_format($item['unit_price'], 2) ?></td>
                            <td>₦<?= number_format($item['subtotal'], 2) ?></td>
                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>