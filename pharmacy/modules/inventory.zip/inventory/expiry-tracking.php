<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$stmt = $pdo->query("SELECT * FROM products
WHERE expiry_date < CURDATE()
ORDER BY expiry_date ASC");

$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="container-fluid mt-4">

    <div class="card">

        <div class="card-header bg-danger text-white">
            <h4>Expired Products</h4>
        </div>

        <div class="card-body">

            <table class="table table-bordered">

                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Batch</th>
                        <th>Expiry Date</th>
                        <th>Quantity</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach($products as $product): ?>

                        <tr>
                            <td><?= htmlspecialchars($product['product_name']) ?></td>
                            <td><?= htmlspecialchars($product['batch_number']) ?></td>
                            <td><?= htmlspecialchars($product['expiry_date']) ?></td>
                            <td><?= $product['quantity'] ?></td>
                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>