<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$message = '';

$products = $pdo->query("SELECT * FROM products ORDER BY product_name ASC")
                ->fetchAll(PDO::FETCH_ASSOC);

if(isset($_POST['adjust'])) {

    $product_id = $_POST['product_id'];
    $new_quantity = $_POST['new_quantity'];

    $stmt = $pdo->prepare("UPDATE products SET quantity = ? WHERE id = ?");

    if($stmt->execute([$new_quantity, $product_id])) {
        $message = 'Stock adjusted successfully';
    }
}
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="container-fluid mt-4">

    <div class="card">

        <div class="card-header">
            <h4>Stock Adjustment</h4>
        </div>

        <div class="card-body">

            <?php if($message): ?>
                <div class="alert alert-success">
                    <?= $message ?>
                </div>
            <?php endif; ?>

            <form method="POST">

                <div class="mb-3">
                    <label>Product</label>

                    <select name="product_id" class="form-select" required>

                        <?php foreach($products as $product): ?>

                            <option value="<?= $product['id'] ?>">
                                <?= htmlspecialchars($product['product_name']) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

                <div class="mb-3">
                    <label>New Quantity</label>

                    <input type="number" name="new_quantity" class="form-control" required>
                </div>

                <button type="submit" name="adjust" class="btn btn-primary">
                    Adjust Stock
                </button>

            </form>

        </div>

    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>