<?php
require_once '../../includes/auth.php';
require_once '../../config/database.php';

$totalProducts = $pdo->query("SELECT COUNT(*) FROM products")
                     ->fetchColumn();

$totalStock = $pdo->query("SELECT SUM(quantity) FROM products")
                  ->fetchColumn();

$lowStock = $pdo->query("SELECT COUNT(*) FROM products
WHERE quantity <= reorder_level")
                ->fetchColumn();

$expired = $pdo->query("SELECT COUNT(*) FROM products
WHERE expiry_date < CURDATE()")
               ->fetchColumn();
?>

<?php require_once '../../includes/header.php'; ?>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="container-fluid mt-4">

    <div class="row">

        <div class="col-md-3">
            <div class="card bg-primary text-white mb-3">
                <div class="card-body">
                    <h5>Total Products</h5>
                    <h2><?= $totalProducts ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card bg-success text-white mb-3">
                <div class="card-body">
                    <h5>Total Stock Qty</h5>
                    <h2><?= $totalStock ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card bg-warning text-dark mb-3">
                <div class="card-body">
                    <h5>Low Stock</h5>
                    <h2><?= $lowStock ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card bg-danger text-white mb-3">
                <div class="card-body">
                    <h5>Expired Products</h5>
                    <h2><?= $expired ?></h2>
                </div>
            </div>
        </div>

    </div>

</div>

<?php require_once '../../includes/footer.php'; ?>